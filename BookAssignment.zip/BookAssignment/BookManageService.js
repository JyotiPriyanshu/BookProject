myApp.service("bookManage",function(){
    this.bookDetails=[
        {bookId:101,bookName:"Believe Yourself",bookAuthor:"Joseph Murphy",bookIsbnCode:"1002",bookDescription:"In Believe in Yourself Dr. Murphy shows you how the power of believing in yourself will help you achieve your dreams.",bookPrice:"500",bookUrl:'C:\\Users\\jp60609\\Angular Training\\BookAssignment\\images\\believe-in-yourself-dr-josephn-murphy.jpg'},
        {bookId:102,bookName:"The Secret",bookAuthor:"Rhonda Byrne",bookIsbnCode:"1078",bookDescription:"who seems intent on running away from lo It is based on the belief of the law of attraction, which claims that thoughts can change a person's life directly.",bookPrice:"670",bookUrl:'C:\\Users\\jp60609\\Angular Training\\BookAssignment\\images\\TheSecret.jpg'},
        {bookId:103,bookName:"The Girl Without A Name",bookAuthor:" Sandra Block",bookIsbnCode:"1002",bookDescription:"he Girl without a Name by Sandra Block is a psychological thriller centering around one doctor's mission to help her patient remember who she is.",bookPrice:"200",bookUrl:'C:\\Users\\jp60609\\Angular Training\\BookAssignment\\images\\R.jpg'},
        {bookId:104,bookName:"The Power Of One",bookAuthor:"Bryce Courtenay",bookIsbnCode:"1011",bookDescription:"The Power of One is at its simplest, a story of self-reliance and perseverance in times of hardship and struggle",bookPrice:"250",bookUrl:'C:\\Users\\jp60609\\Angular Training\\BookAssignment\\images\\T.jpg'}]
    this.getAllBookDetails=function()
    {
        return this.bookDetails;
    }
    this.addBook=function(book)
    {
        
        this.bookDetails.push(book);

    }
    
    this.deleteBook=function(book){
        var pos=this.bookDetails.findIndex(item=> {
            if(item.bookId == book.bookId)
            {
                return true;
            }
            else
            {
                return false;
            }
        })

        this.bookDetails.splice(pos,1);
    } 
})
