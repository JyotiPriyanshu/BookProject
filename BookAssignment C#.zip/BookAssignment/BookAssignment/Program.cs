﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*   2.Create a book store :Angular js
* 
* Book -- Id, Name, author, ISBN code, descr
* iption of book, price, bookImage
* Display various books  
* Along with each book, Edit the book details, delete the book details, display the decription;
*add a new book option should also be there
* 
* In .net -- perform the same operations
* 
* 1. Edit the book
* 2. Delete 
* 3. Add
* 4. Show description
* 5. Display
* 6. Exit
*/

namespace BookAssignment
{
    public class Book
    {
        int bId;
        string bName;
        string bAuthor;
        int ISBNCode;
        string description;
        double price;

        public Book() { }
        public int BId { get; set; }

        public Book(int bId, string bName, string bAuthor, int iSBNCode, string description, double price)
        {
            this.bId = bId;
            this.bName = bName;
            this.bAuthor = bAuthor;
            this.ISBNCode = iSBNCode;
            this.description = description;
            this.price = price;


        }
        public override string ToString()
        {
            return $"bookID : {bId}; Book Name : {bName}; Author Name : {bAuthor}; ISBNCode : {ISBNCode}; Book Description : {description}; Book Price : {price}; ";
        }

        public void editBook(List<Book> blist, int bid)//non static method as static keyword is not used .we should call using object of the class
        {

            for (int i = 0; i < blist.Count; i++)
            {
                if (blist[i].bId == bid)
                {
                    Console.WriteLine("Enter the edited bookName:");
                    string name = Console.ReadLine();
                    Console.WriteLine("Enter the edited bookPrice:");
                    double prc = Convert.ToDouble(Console.ReadLine());
                    blist[i].bName = name;
                    blist[i].price = prc;

                    Console.WriteLine("Book after editing: " + blist[i].ToString());
                }

            }
        }
        public void addNewBook(List<Book> bookList)
        {
            Console.WriteLine("Enter new book Id : ");
            int newID = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter new book Name : ");
            string newName = Console.ReadLine();
            Console.WriteLine("Enter new book Author : ");
            string newAuthor = Console.ReadLine();
            Console.WriteLine("Enter new book ISBN : ");
            int newIsbn = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter new book Description : ");
            string newDes = Console.ReadLine();
            Console.WriteLine("Enter new book Price: ");
            double newPrice = Convert.ToDouble(Console.ReadLine());

            bookList.Add(new Book(newID,newName,newAuthor,newIsbn,newDes,newPrice));
           for(int i = 0; i < bookList.Count; i++)
            {
                Console.WriteLine(bookList[i].ToString() );
            }
        }
        public void deleteParticularBook(List<Book> bookList, int id)
        {
            bool b = false;
            for (int i = 0; i < bookList.Count; i++)
            {
                if (bookList[i].bId == id)
                {
                    b = true;
                   bookList.RemoveAt(i);
                }
                    
            }
            if (b == true)
            {
                Console.WriteLine("Book is Deleted");
            }
            else
            {
                Console.WriteLine("No Book Found with the given ID to Delete");
            }
        }
        public void showParticularBook(List<Book> bookList, int id)
        {
            Book temp = null;
            for (int i = 0; i < bookList.Count; i++)
            {
                if (bookList[i].bId == id)
                    temp = bookList[i];

            }
            if (temp != null)
            {
                Console.WriteLine(temp.ToString());
            }
            else
            {
                Console.WriteLine("No Book Found with the given ID");
            }
        }
        public void displayBook(List<Book> bookList)
        {
            for (int i = 0; i < bookList.Count; i++)
            {
                Console.WriteLine(bookList[i].ToString());
            }
        }

    }
    internal class Program
    {
        static void Main(string[] args)
        {
            List<Book> books = new List<Book>
            {
                new Book(101,"C#","Andrew",12005,"good Book",250.98),
                new Book(102,".Net","Edvert",11112,"good Book",150.00),
                new Book(103,"C++","bzarne",10005,"good Book",2504.11),
                new Book(104,"java","James Gosline",1555,"good Book",1250.00),
                new Book(105,"C","Denish",15000,"good Book",1999.99),
            };


            
            Book bookObj = new Book();
            Console.WriteLine("Original BookList : ");
            bookObj.displayBook(books);
            bool val = true;
            while (val) { 
           
            Console.WriteLine(" 1. Edit the book");
            Console.WriteLine(" 2. Delete the book");
            Console.WriteLine(" 3. Add the book");
            Console.WriteLine(" 4. Show Details of Particular book");
            Console.WriteLine(" 5. Display the book");
            Console.WriteLine(" 6. Exit");

            Console.WriteLine("Enter Your Choice ");
            int num = int.Parse(Console.ReadLine());


                switch (num)
                {
                    case 1:
                        Console.WriteLine("Enter the book Id you want to Edit:");
                        int bid = Convert.ToInt32(Console.ReadLine());
                        bookObj.editBook(books, bid);
                        break;


                    case 2:
                        Console.WriteLine("Enter the Id of book You  want to delete");
                        int deleteId = int.Parse(Console.ReadLine());
                        bookObj.deleteParticularBook(books, deleteId);
                        break;
                    case 3:
                        Console.WriteLine("how many books You want to add");
                        int n = int.Parse(Console.ReadLine());

                        for (int i = 1; i <= n; i++)
                        {
                            bookObj.addNewBook(books);
                        }
                        break;

                    case 4:
                        Console.WriteLine("showing display of book");
                        Console.WriteLine("Enter the Book Id to find its Details");
                        int Id = Convert.ToInt32(Console.ReadLine());
                        bookObj.showParticularBook(books,Id);
                    break;

                    case 5:
                        Console.WriteLine("All Books are : ");
                        bookObj.displayBook(books);

                        break;
                    case 6:
                        val = false;
                        break;
                    default:
                        Environment.Exit(default);

                        break;
                }
            }

            Console.WriteLine("Exit Executed... Application Stopped. ");
            Console.ReadLine();
        }

    }
}

